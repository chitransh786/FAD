import sys

def crash():
    print("Crashing the bot now...")
    sys.exit(1)  # Exits the program with an error code

# Example usage
# crash_bot()
